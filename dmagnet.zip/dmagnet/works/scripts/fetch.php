<?php 

$conn = mysqli_connect("localhost","root","","dmm");

$query = "SELECT * FROM yt  ORDER BY id DESC";
$query_run = mysqli_query($conn, $query);
$result_array = [];

if(mysqli_num_rows($query_run) > 0)
{
    foreach($query_run as $row)
    {
        array_push($result_array, $row);
    }
    header('Content-type: application/json');
    echo json_encode($result_array);
}
else
{
    echo $return = "<h4>No Record Found</h4>";
}
?>




    <?php
//    if(isset($_POST["action"])){
// $connect = mysqli_connect("localhost", "root", "", "dmm");
// if($_POST["action"] == "fetch"){
//  $query = "SELECT * FROM yt ORDER BY id DESC";
//  $result = mysqli_query($connect, $query);
//     
//       $output = '    <div class="container">
//        <div class="row">
//        <div class="col-sm-3 pt-5 mt-5">
//       
//       ';
//while($row = mysqli_fetch_array($result)){
//    $output .= '<div> .$row['links']. </div>';
//    }
//$output .= '</div> </div>  </div>';
//  echo $output;
//
// }
//      
//    }

    ?>
