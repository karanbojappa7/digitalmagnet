 <?php
include "contact.php";
$links = $_POST['links'];
$query=("INSERT INTO yt(links) VALUES('$links')");
mysqli_query($mysqli,$query);
?>